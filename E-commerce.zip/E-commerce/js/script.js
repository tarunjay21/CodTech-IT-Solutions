
//js code

/*function checkout() {
  // Example: Redirect to a checkout page or handle the checkout process
  alert('Checkout clicked! Implement your checkout logic here.');
}*/





